#include <assert.h>
#include <stdbool.h>
#include "../src/deck.h"

void test_deck() {
  assert(true);
}
