#include <assert.h>
#include <stdbool.h>
#include "../src/gui.h"

void test_gui() {
  assert(true);
}
