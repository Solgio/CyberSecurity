#include <assert.h>
#include <stdbool.h>
#include "../src/cursor.h"

void test_cursor() {
  assert(true);
}
