#ifndef TTY_SOLITAIRE_TEST_H
#define TTY_SOLITAIRE_TEST_H

void test_card();
void test_cursor();
void test_deck();
void test_gui();
void test_frame();
void test_game();
void test_keyboard();
void test_stack();
void test_test_helper();

#endif
